package okay.scala3.std

import okay.scala3.*
import scala.annotation.unused

import java.util.concurrent.atomic.AtomicReference
import scala.concurrent.{ExecutionContext, Future, Promise}
import scala.util.control.NonFatal
import scala.util.{Failure, Success, Try}

/** AN ASYNCHRONOUS OPERATION: `Suspend(register)`, the program waiting until `register`'s callback is called — with
 * its value, or its failure; `register` gives back how to cancel the wait (a timer cleared, another run cancelled).
 * okay-simple's `async`, on this machine */
enum Async[X]:
  case Suspend[X](register: (Either[Throwable, X] => Unit) => (() => Unit)) extends Async[X]

/** a program running: its value to come, and how to cancel it — the wait it is in cancelled, the rest left: never
 * run, its finalizers run (`ensuring`); the future failed with [[Cancelled]] */
final class Running[A](val future: Future[A], cancelling: () => Unit):
  def cancel(): Unit = cancelling()

/** a program started on its own (`Async.fork`): its value awaited, or it cancelled */
final class Fiber[A](val running: Running[A]):
  /** its value when it ends; its failure, or `Cancelled`, failing the program that waits. Cancelling the wait does not
   * cancel the fiber */
  def join[R[_]](using In[Async, R]): A ! R = Async.fromFuture(running.future)
  /** the fiber cancelled: the wait it is in cancelled, its rest left — never run, its finalizers run */
  def cancel[R[_]]: Unit ! R = defer(pure(running.cancel()))

/** what a cancelled program's future fails with */
final class Cancelled extends RuntimeException("cancelled")

/**
 * ASYNCHRONY with no runtime of its own: a program of `Async` waits on callbacks, and `toFuture` drives it — runs it to
 * its next wait, registers the callback, and when it is called resumes the rest on the execution context, until it is
 * done: a `Future` of its value, failed if a callback gave a failure or the program threw. A program's other effects
 * are handled first, its row then `Async` alone. On every platform; `sleep` by the platform's timer.
 *
 * A PROGRAM THAT WAITS IS KEPT, and its finalizers (`ensuring`) run when it ends. One that will not go on is LEFT —
 * its wait failed, or it was cancelled (`cancel`, the loser of a `race`, a `timeout`, a fiber of a `Scope` that
 * ended): its finalizers run then, on the thread that leaves it, each up to its first wait. A throw out of the
 * program runs none.
 */
object Async:
  /** an operation answered by a callback, called once; it cannot be cancelled */
  def async[X, R[_]](register: (Either[Throwable, X] => Unit) => Unit)(using In[Async, R]): X ! R =
    cancellable[X, R] { cb =>
      register(cb)
      noCancel
    }

  /** an operation answered by a callback, called once; `register` gives back how to cancel it */
  def cancellable[X, R[_]](register: (Either[Throwable, X] => Unit) => (() => Unit))(using In[Async, R]): X ! R =
    perform[Async](Suspend(register))

  /** `f`'s value when it completes; `f` made when the program gets here */
  def fromFuture[X, R[_]](f: => Future[X])(using In[Async, R]): X ! R =
    async[X, R](cb => f.onComplete {
      case Success(x) => cb(Right(x))
      case Failure(e) => cb(Left(e))
    }(using ExecutionContext.parasitic))

  /** `f` run on `pool` — a blocking call, a thread of its own — its value or what it throws: the thread that got here
   * free at once, the program resumed when `f` ends */
  def blocking[X, R[_]](f: => X)(using pool: ExecutionContext, at: In[Async, R]): X ! R =
    async[X, R](cb => pool.execute(() => cb(Try(f).toEither)))

  /** a wait that never ends: until cancelled */
  def never[X, R[_]](using In[Async, R]): X ! R = cancellable[X, R](_ => noCancel)

  /** `p` started on its own, the program going on: a fiber, to join or cancel */
  def fork[A, R[_]](p: A ! Async)(using ec: ExecutionContext, @unused at: In[Async, R]): Fiber[A] ! R =
    defer(pure(Fiber(start(p))))

  /** `ms` milliseconds later */
  def sleep[R[_]](ms: Long)(using In[Async, R]): Unit ! R =
    cancellable[Unit, R](cb => Timers.after(ms)(() => cb(Right(()))))

  /** the platform's execution context: the global one on the JVM and Scala Native, the microtask queue on Scala.js */
  def defaultContext: ExecutionContext = Timers.executionContext

  /** the program driven to its end: its value, a `Future` */
  def toFuture[A](p: A ! Async)(using ExecutionContext): Future[A] = start(p).future

  /** the program started: its future, and how to cancel it */
  def start[A](p: A ! Async)(using ec: ExecutionContext): Running[A] =
    val done = Promise[A]()
    val run = Run()
    drive(coroutine(p), done, run)
    Running(done.future, () => run.cancel(done))

  /** both at once, each run on its own: both values; one failing, the other cancelled; this cancelled, both */
  def both[A, B](p: A ! Async, q: B ! Async)(using ExecutionContext): (A, B) ! Async =
    cancellable[(A, B), Async] { cb =>
      val ra = start(p)
      val rb = start(q)
      ra.future.failed.foreach(_ => rb.cancel())
      rb.future.failed.foreach(_ => ra.cancel())
      ra.future.zip(rb.future).onComplete {
        case Success(ab) => cb(Right(ab))
        case Failure(e) => cb(Left(e))
      }
      () =>
        ra.cancel()
        rb.cancel()
    }

  /** each element's program at once: their values, in order; one failing, the others cancelled */
  def parTraverse[X, A](xs: List[X])(f: X => A ! Async)(using ExecutionContext): List[A] ! Async =
    cancellable[List[A], Async] { cb =>
      val runs = xs.map(x => start(f(x)))
      runs.foreach(r => r.future.failed.foreach(_ => runs.foreach(_.cancel())))
      Future.sequence(runs.map(_.future)).onComplete {
        case Success(as) => cb(Right(as))
        case Failure(e) => cb(Left(e))
      }
      () => runs.foreach(_.cancel())
    }

  /** the first to end: its value — the other cancelled */
  def race[A, B](p: A ! Async, q: B ! Async)(using ExecutionContext): Either[A, B] ! Async =
    cancellable[Either[A, B], Async] { cb =>
      val ra = start(p)
      val rb = start(q)
      Future.firstCompletedOf(List(ra.future.map(Left(_)), rb.future.map(Right(_)))).onComplete { r =>
        ra.cancel()
        rb.cancel()
        r match
          case Success(v) => cb(Right(v))
          case Failure(e) => cb(Left(e))
      }
      () =>
        ra.cancel()
        rb.cancel()
    }

  /** the value if the program ends within `ms` milliseconds: else `None`, the program cancelled */
  def timeout[A](ms: Long)(p: A ! Async)(using ExecutionContext): Option[A] ! Async =
    race(p, sleep[Async](ms)).map(_.left.toOption)

  /** a wait that cannot be cancelled */
  val noCancel: () => Unit = () => ()

  // ---- THE DRIVER: the program as a coroutine of waits, each registered, the rest resumed by its callback

  /** where a program stands: done, or waiting — `k` the rest, a program of no effect */
  private enum Waiting[A]:
    case Done(a: A)
    case Suspended[A, X](register: (Either[Throwable, X] => Unit) => (() => Unit), k: X => Waiting[A] ! Pure)
      extends Waiting[A]

  private def coroutine[A](p: A ! Async): Waiting[A] ! Pure =
    handle(p, Handler.general[Async, Pure, A, Waiting[A]](a => pure(Waiting.Done(a)))(
      [X] => (op: Async[X], k: X => Waiting[A] ! Pure) => op match
        case Suspend(register) => pure(Waiting.Suspended(register, k))))

  /** a run's state: cancelled or not, and what a cancel does to the wait it is in */
  private final class Run:
    @volatile var cancelled = false
    val waiting = AtomicReference[() => Unit](noCancel)
    def cancel[B](done: Promise[B]): Unit = if !cancelled then
      cancelled = true
      waiting.getAndSet(noCancel)()
      done.tryFailure(Cancelled())
    /** the wait now: cancelled at once if the run was, meanwhile */
    def waitingOn(c: () => Unit): Unit =
      waiting.set(c)
      if cancelled then waiting.getAndSet(noCancel)()

  /** the slot's marks: `register` returned before its callback was called; and the wait cancelled before it was */
  private object Later extends RuntimeException("later", null, false, false)
  private val later: Either[Throwable, Nothing] = Left(Later)
  private val left: Either[Throwable, Nothing] = Left(Later)

  /** THE REST LEFT, the run failed with `e`: a wait that failed, or was cancelled. Its finalizers run (`ensuring`),
   * here and now, each up to its first wait — `Async`'s handler has left, and nobody answers one. A finalizer that
   * throws fails the run with what it threw */
  private def leave[A, X](k: X => Waiting[A] ! Pure, e: Throwable, done: Promise[A]): Unit =
    try k match
      // the rest as the machine gives it: `Waiting` keeps it as the function it was in 0.1.1, for its bytecode
      case rest: Continuation[X, Pure, Waiting[A]] => okay.scala3.runIsolated(rest.unwind)
      case _ => ()
    catch case NonFatal(thrown) => done.tryFailure(thrown)
    done.tryFailure(e)

  /** the rest resumed with its answer; a run cancelled meanwhile leaves it */
  private def resume[A, X](k: X => Waiting[A] ! Pure, x: X, done: Promise[A], run: Run)(
    using ExecutionContext): Unit =
    if run.cancelled then leave(k, Cancelled(), done) else drive(k(x), done, run)

  /** a loop: a callback called while `register` runs — a future already done — is taken here and the loop goes on;
   * one called later resumes the rest on the execution context. A wait is settled once — by its callback, or by the
   * run's cancel, which leaves the rest: one `compareAndSet` of its slot decides which */
  private def drive[A](p: Waiting[A] ! Pure, done: Promise[A], run: Run)(using ec: ExecutionContext): Unit =
    var next: Option[Waiting[A] ! Pure] = Some(p)
    try
      while next.isDefined do
        val now = next.get
        next = None
        okay.scala3.runIsolated(now) match
          case Waiting.Done(a) => done.trySuccess(a)
          case s: Waiting.Suspended[a, x] =>
            val slot = AtomicReference[Either[Throwable, x]](null)
            val cancel = s.register { r =>
              if !slot.compareAndSet(null, r) && slot.compareAndSet(later, r) then
                run.waiting.set(noCancel)
                r match
                  case Right(x) => ec.execute(() => resume(s.k, x, done, run))
                  case Left(e) => leave(s.k, e, done)
            }
            if slot.compareAndSet(null, later) then run.waitingOn { () =>
              if slot.compareAndSet(later, left) then
                cancel()
                leave(s.k, Cancelled(), done)
            }
            else slot.get match
              case Right(x) => if run.cancelled then leave(s.k, Cancelled(), done) else next = Some(s.k(x))
              case Left(e) => leave(s.k, e, done)
    catch case NonFatal(e) => done.tryFailure(e)
